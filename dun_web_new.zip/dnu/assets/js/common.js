//Fixed services menu 
// $(function() {
//     $(window).scroll(function(e) {
//         if ($(this).scrollTop() > 380) {
//             $('.services-list').addClass("services-list-fixed col-sm-3")
//         } else {
//             $('.services-list').removeClass("services-list-fixed col-sm-3")
//         }
//     });
// });